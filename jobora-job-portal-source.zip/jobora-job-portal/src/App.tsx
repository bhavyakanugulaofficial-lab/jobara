import { useMemo, useState } from 'react'
import { ArrowRight, Check, ChevronDown, Filter, Search, SlidersHorizontal, X } from 'lucide-react'
import { motion } from 'framer-motion'
import { jobs } from './data/jobs'
import { articles } from './data/content'
import { jobCategories, type Article, type Job, type JobCategory, type JobFilters } from './types'
import { Navigation, type SiteAction } from './components/Navigation'
import { Hero } from './components/Hero'
import { CategoryGrid } from './components/CategoryGrid'
import { FilterPanel } from './components/FilterPanel'
import { JobCard } from './components/JobCard'
import { CompaniesSection } from './components/CompaniesSection'
import { CareerAdvice } from './components/CareerAdvice'
import { JobDetailsModal } from './components/JobDetailsModal'
import { ApplyModal } from './components/ApplyModal'
import { ArticleModal } from './components/ArticleModal'
import { InfoModal, type InfoContent } from './components/InfoModal'
import { SiteFooter } from './components/SiteFooter'

const initialFilters: JobFilters = {
  query: '',
  locationQuery: '',
  category: '',
  location: '',
  type: '',
  experience: '',
  salary: '',
}

function scrollToJobs() {
  document.getElementById('find-jobs')?.scrollIntoView({ behavior: 'smooth', block: 'start' })
}

export default function App() {
  const [filters, setFilters] = useState<JobFilters>(initialFilters)
  const [sortBy, setSortBy] = useState('newest')
  const [mobileFiltersOpen, setMobileFiltersOpen] = useState(false)
  const [savedJobs, setSavedJobs] = useState<string[]>([])
  const [activeJob, setActiveJob] = useState<Job | null>(null)
  const [applicationJob, setApplicationJob] = useState<Job | null>(null)
  const [applicationReturnJob, setApplicationReturnJob] = useState<Job | null>(null)
  const [activeArticle, setActiveArticle] = useState<Article | null>(null)
  const [infoContent, setInfoContent] = useState<InfoContent | null>(null)

  const locations = useMemo(() => [...new Set(jobs.map((job) => job.location))].sort((a, b) => a.localeCompare(b)), [])
  const categoryCounts = useMemo(() => {
    const counts = Object.fromEntries(jobCategories.map((category) => [category, jobs.filter((job) => job.category === category).length])) as Record<JobCategory, number>
    return counts
  }, [])

  const filteredJobs = useMemo(() => {
    const query = filters.query.trim().toLowerCase()
    const locationText = filters.locationQuery.trim().toLowerCase()
    const result = jobs.filter((job) => {
      const searchable = [job.title, job.company, job.category, job.location, job.description, job.about, job.employmentType, job.workMode, job.experience, ...job.tags, ...job.skills].join(' ').toLowerCase()
      if (query && !searchable.includes(query)) return false
      if (locationText && !job.location.toLowerCase().includes(locationText)) return false
      if (filters.location && job.location !== filters.location) return false
      if (filters.category && job.category !== filters.category) return false
      if (filters.type === 'Remote' && job.workMode !== 'Remote') return false
      if (filters.type && filters.type !== 'Remote' && job.employmentType !== filters.type) return false
      if (filters.experience && job.experience !== filters.experience) return false
      if (filters.salary === 'under10' && job.salaryMaxLpa > 10) return false
      if (filters.salary === '10to20' && !(job.salaryMaxLpa >= 10 && job.salaryMinLpa < 20)) return false
      if (filters.salary === '20to35' && !(job.salaryMaxLpa >= 20 && job.salaryMinLpa < 35)) return false
      if (filters.salary === '35plus' && job.salaryMaxLpa < 35) return false
      return true
    })
    if (sortBy === 'salary-high') result.sort((a, b) => b.salaryMaxLpa - a.salaryMaxLpa)
    else if (sortBy === 'salary-low') result.sort((a, b) => a.salaryMinLpa - b.salaryMinLpa)
    else result.sort((a, b) => a.postedDays - b.postedDays)
    return result
  }, [filters, sortBy])

  const updateFilter = (key: keyof JobFilters, value: string) => setFilters((current) => ({ ...current, [key]: value }))
  const clearFilters = () => {
    setFilters(initialFilters)
    setSortBy('newest')
    setMobileFiltersOpen(false)
  }
  const toggleSaved = (jobId: string) => {
    setSavedJobs((current) => current.includes(jobId) ? current.filter((id) => id !== jobId) : [...current, jobId])
  }
  const chooseCategory = (category: JobCategory) => {
    updateFilter('category', category)
    scrollToJobs()
  }
  const chooseTag = (value: string) => {
    updateFilter('query', value === 'Internships' ? 'Internship' : value)
    scrollToJobs()
  }
  const chooseCompany = (company: string) => {
    setFilters({ ...initialFilters, query: company })
    scrollToJobs()
  }
  const openAction = (action: SiteAction) => {
    const info: Record<SiteAction, InfoContent> = {
      login: { title: 'Your next role, no account required.', body: 'Sign-in and account creation are intentionally disabled in this frontend-only preview. Browse openings, explore details, and save sample roles in this session.' },
      post: { title: 'A better way to meet great people.', body: 'The employer workspace is a visual preview only. Job posts cannot be created or published here, and all openings on the site are sample listings.' },
      profile: { title: 'Your career space, thoughtfully organised.', body: 'Profile and account features are not connected in this demo. You can explore the experience without creating an account or sharing personal information.' },
    }
    setInfoContent(info[action])
  }
  const startApplication = (job: Job) => {
    setApplicationReturnJob(null)
    setActiveJob(null)
    setApplicationJob(job)
  }
  const startApplicationFromDetails = (job: Job) => {
    setApplicationReturnJob(job)
    setActiveJob(null)
    setApplicationJob(job)
  }
  const closeApplication = () => {
    setApplicationJob(null)
    if (applicationReturnJob) setActiveJob(applicationReturnJob)
    setApplicationReturnJob(null)
  }

  return (
    <div className="app-shell">
      <a className="skip-link" href="#main-content">Skip to content</a>
      <Navigation onAction={openAction} />
      <main id="main-content">
        <Hero
          query={filters.query}
          locationQuery={filters.locationQuery}
          onQueryChange={(value) => updateFilter('query', value)}
          onLocationChange={(value) => updateFilter('locationQuery', value)}
          onSearch={scrollToJobs}
          onTag={chooseTag}
        />

        <section className="trust-strip" aria-label="Jobora approach">
          <div className="container trust-strip__inner">
            <span className="trust-strip__intro">A little more signal. A lot less noise.</span>
            <span><i className="trust-symbol trust-symbol--one" />Roles with room to grow</span>
            <span><i className="trust-symbol trust-symbol--two" />Thoughtful company discovery</span>
            <span><i className="trust-symbol trust-symbol--three" />Useful context, up front</span>
          </div>
        </section>

        <section className="category-section section" id="categories">
          <div className="container">
            <div className="section-heading section-heading--row">
              <div><span className="eyebrow">START WITH WHAT MOVES YOU</span><h2>Find your kind<br className="desktop-break" /> of work.</h2></div>
              <div className="section-heading__aside"><p>Whether you’re building, designing, analysing, or leading — begin with the work you want more of.</p><a className="inline-link" href="#find-jobs">Explore all roles <ArrowRight size={15} /></a></div>
            </div>
            <CategoryGrid counts={categoryCounts} onSelect={chooseCategory} />
          </div>
        </section>

        <section className="jobs-section section" id="find-jobs">
          <div className="container">
            <div className="jobs-intro">
              <div className="jobs-intro__copy"><span className="eyebrow">A GOOD PLACE TO BEGIN</span><h2>Make room for<br className="desktop-break" /> what’s next.</h2><p>Explore a considered mix of opportunities across teams, industries, and ways of working.</p></div>
              <div className="jobs-intro__stat"><span className="stat-number">{jobs.length.toString().padStart(2, '0')}</span><span>sample roles<br />to explore</span><i className="stat-rule" /><span className="stat-footnote">A starting point,<br />not a live job board.</span></div>
            </div>
            <div className="jobs-control-bar">
              <div className="jobs-inline-search">
                <Search size={17} aria-hidden="true" />
                <label className="sr-only" htmlFor="results-search">Search sample jobs</label>
                <input id="results-search" type="search" value={filters.query} onChange={(event) => updateFilter('query', event.target.value)} placeholder="Search roles, companies, or skills" />
                {filters.query && <button className="search-clear" type="button" onClick={() => updateFilter('query', '')} aria-label="Clear search"><X size={15} /></button>}
              </div>
              <div className="jobs-control-bar__right">
                <button className="filter-toggle button button--outline" type="button" aria-expanded={mobileFiltersOpen} onClick={() => setMobileFiltersOpen((value) => !value)}><SlidersHorizontal size={16} /> Filters <span>{[filters.category, filters.location, filters.type, filters.experience, filters.salary].filter(Boolean).length || ''}</span></button>
                <label className="sort-select"><span>Sort</span><select value={sortBy} onChange={(event) => setSortBy(event.target.value)} aria-label="Sort job results"><option value="newest">Newest first</option><option value="salary-high">Salary: high to low</option><option value="salary-low">Salary: low to high</option></select><ChevronDown size={14} aria-hidden="true" /></label>
              </div>
            </div>
            <div className="results-summary" aria-live="polite">
              <span><strong>{filteredJobs.length}</strong> {filteredJobs.length === 1 ? 'sample role' : 'sample roles'} found</span>
              <span className="results-summary__right">{savedJobs.length > 0 && <span className="saved-count"><Check size={13} /> {savedJobs.length} saved</span>}<span>Listings are for demonstration only</span></span>
            </div>
            <div className="jobs-layout">
              <FilterPanel filters={filters} onChange={updateFilter} onClear={clearFilters} locations={locations} isOpen={mobileFiltersOpen} onClose={() => setMobileFiltersOpen(false)} />
              <div className="job-results-main">
                {filters.category && <div className="active-filter-banner"><span>Showing <strong>{filters.category}</strong> roles</span><button type="button" onClick={() => updateFilter('category', '')}>Clear category <X size={14} /></button></div>}
                {filteredJobs.length > 0 ? (
                  <div className="jobs-grid">
                    {filteredJobs.map((job, index) => <JobCard key={job.id} job={job} index={index} isSaved={savedJobs.includes(job.id)} onSave={toggleSaved} onView={setActiveJob} onApply={startApplication} />)}
                  </div>
                ) : (
                  <div className="empty-state">
                    <span className="empty-state__icon"><Filter size={20} /></span>
                    <span className="eyebrow">NO MATCHES THIS TIME</span>
                    <h3>Try a different direction.</h3>
                    <p>We couldn’t find a sample role for that combination. Loosen a filter or search a broader term.</p>
                    <button className="button button--primary" type="button" onClick={clearFilters}>Clear all filters <ArrowRight size={15} /></button>
                  </div>
                )}
                <div className="results-footnote"><span className="results-footnote__mark">i</span><p>These listings, salaries, and company details are illustrative sample data. They are not verified live vacancies or employment offers.</p></div>
              </div>
            </div>
            {filteredJobs.length > 6 && <div className="jobs-bottom-note"><span>That’s the full sample collection.</span><span>Built for exploration, not applications. <i /></span></div>}
          </div>
        </section>

        <CompaniesSection jobs={jobs} onCompanyClick={chooseCompany} />

        <section className="career-banner">
          <div className="container career-banner__inner">
            <div><span className="eyebrow">A LITTLE MORE CLARITY</span><h2>Good work is a journey.<br /><span>Let’s make the next step count.</span></h2></div>
            <a className="button button--light" href="#career-advice">Find your next step <ArrowRight size={16} /></a>
            <div className="career-banner__ornament" aria-hidden="true"><span /><span /><span /></div>
          </div>
        </section>

        <CareerAdvice articles={articles} onRead={setActiveArticle} />
      </main>
      <SiteFooter onAction={openAction} onInfo={setInfoContent} />

      <JobDetailsModal job={activeJob} onClose={() => setActiveJob(null)} onApply={startApplicationFromDetails} />
      <ApplyModal job={applicationJob} onClose={closeApplication} />
      <ArticleModal article={activeArticle} onClose={() => setActiveArticle(null)} />
      <InfoModal content={infoContent} onClose={() => setInfoContent(null)} />
    </div>
  )
}

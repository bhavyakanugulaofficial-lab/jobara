export const jobCategories = [
  'Software & Technology',
  'Design & Creative',
  'Marketing',
  'Business & Finance',
  'Data & Analytics',
  'Human Resources',
  'Customer Support',
  'Engineering',
] as const

export type JobCategory = (typeof jobCategories)[number]
export type EmploymentType = 'Full-time' | 'Part-time' | 'Internship' | 'Contract'
export type WorkMode = 'Remote' | 'Hybrid' | 'On-site'
export type ExperienceLevel = 'Entry level' | 'Mid-level' | 'Senior'

export interface JobFilters {
  query: string
  locationQuery: string
  category: string
  location: string
  type: string
  experience: string
  salary: string
}

export interface Job {
  id: string
  title: string
  company: string
  companyAbbr: string
  brandColor: string
  category: JobCategory
  location: string
  country: string
  salary: string
  salaryMinLpa: number
  salaryMaxLpa: number
  employmentType: EmploymentType
  workMode: WorkMode
  experience: ExperienceLevel
  description: string
  postedDays: number
  tags: string[]
  companyDescription: string
  about: string
  responsibilities: string[]
  qualifications: string[]
  skills: string[]
}

export interface Article {
  id: string
  title: string
  category: string
  readTime: string
  date: string
  excerpt: string
  accent: string
  art: 'resume' | 'interview' | 'skills'
  body: string[]
}

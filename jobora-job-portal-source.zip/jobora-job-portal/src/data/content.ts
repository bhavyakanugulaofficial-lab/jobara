import type { Article } from '../types'

export const articles: Article[] = [
  {
    id: 'resume', title: 'How to build a strong resume', category: 'Career foundations', readTime: '6 min read', date: 'A practical guide', excerpt: 'Make your experience easy to understand, easy to trust, and hard to overlook.', accent: 'lavender', art: 'resume',
    body: [
      'A strong resume is not a complete record of everything you have done. It is a clear argument for why your next step makes sense. Start by reading the role carefully and identify the two or three capabilities the team needs most.',
      'Write bullets around outcomes, not responsibilities. Give the reader context, your contribution, and the result. A small, specific improvement is more convincing than a broad claim: “reduced weekly reporting from four hours to one” tells a clearer story than “excellent analytical skills.”',
      'Keep the layout calm and easy to scan. Use consistent dates, plain section labels, and enough whitespace. Proofread names, links, and numbers, then ask someone outside your field to tell you what they think you are good at after a quick read.',
    ],
  },
  {
    id: 'interview', title: 'Preparing for technical interviews', category: 'Interviewing', readTime: '8 min read', date: 'A calmer way to prepare', excerpt: 'A simple preparation rhythm for showing how you think, not just what you know.', accent: 'peach', art: 'interview',
    body: [
      'Preparation works best when it is deliberate and bounded. Review the role and company, choose a few representative problems, and leave time to rest. The goal is not to memorise every possible answer; it is to become comfortable explaining your decisions.',
      'When you solve a problem, narrate your assumptions. Ask clarifying questions, outline a straightforward approach, and discuss trade-offs before optimising. In system design conversations, be explicit about scale, failure modes, and what you would measure after launch.',
      'For behavioural questions, prepare a small set of real stories using situation, action, and outcome. Be candid about what you would change. Thoughtful reflection often reveals more than a perfectly polished story.',
    ],
  },
  {
    id: 'first-job', title: 'Essential skills for your first job', category: 'Early career', readTime: '5 min read', date: 'A confident first step', excerpt: 'The habits that help new professionals learn quickly and contribute with confidence.', accent: 'mint', art: 'skills',
    body: [
      'You do not need to arrive knowing everything. The most valuable early-career skill is learning how to learn: take useful notes, look for patterns, and make your next question more specific than the last one.',
      'Build reliability through small habits. Confirm what “done” means, share progress before someone has to ask, and communicate early when a plan changes. These behaviours make it easier for teammates to trust your work and offer meaningful support.',
      'Finally, get comfortable asking for feedback. Request one concrete thing to continue and one to try differently. A growth mindset is most powerful when it becomes a regular practice, not just a phrase on a profile.',
    ],
  },
]

export const featuredCompanies = [
  { name: 'Razorpay', industry: 'Financial technology', location: 'Bengaluru, India', color: '#2457E6', abbr: 'R', note: 'Payments that move business forward.' },
  { name: 'Atlassian', industry: 'Software & collaboration', location: 'Hyderabad, India', color: '#1264A3', abbr: 'A', note: 'Build tools for teams everywhere.' },
  { name: 'CRED', industry: 'Consumer technology', location: 'Bengaluru, India', color: '#17181B', abbr: 'C', note: 'Design-led financial experiences.' },
  { name: 'Microsoft', industry: 'Technology', location: 'Hyderabad, India', color: '#2878D0', abbr: 'M', note: 'Empower every person and organisation.' },
  { name: 'Airbnb', industry: 'Travel & hospitality', location: 'Remote · India', color: '#FF5A5F', abbr: 'A', note: 'Create a world where anyone can belong.' },
  { name: 'Canva', industry: 'Visual communication', location: 'Sydney, Australia', color: '#00AFC0', abbr: 'C', note: 'Make design simple for everyone.' },
]

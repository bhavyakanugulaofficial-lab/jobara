import { ArrowUpRight } from 'lucide-react'
import type { Article } from '../types'
import { Dialog } from './Dialog'

export function ArticleModal({ article, onClose }: { article: Article | null; onClose: () => void }) {
  return (
    <Dialog open={Boolean(article)} onClose={onClose} labelledBy="article-dialog-title" className="dialog--article">
      {article && (
        <article className="article-detail">
          <div className={`article-art article-art--${article.art}`} aria-hidden="true"><span className="article-art__overline">JOBORA FIELD NOTES</span><span className="article-art__large">{article.art === 'resume' ? 'MAKE IT\nCLEAR.' : article.art === 'interview' ? 'THINK OUT\nLOUD.' : 'START WITH\nCURIOSITY.'}</span></div>
          <div className="article-detail__body">
            <div className="article-meta"><span>{article.category}</span><span>·</span><span>{article.readTime}</span></div>
            <h2 id="article-dialog-title">{article.title}</h2>
            <p className="article-detail__intro">{article.excerpt}</p>
            {article.body.map((paragraph, index) => <p key={index}>{paragraph}</p>)}
            <div className="article-detail__end"><span>Thoughtful work starts with thoughtful preparation.</span><ArrowUpRight size={16} /></div>
          </div>
        </article>
      )}
    </Dialog>
  )
}

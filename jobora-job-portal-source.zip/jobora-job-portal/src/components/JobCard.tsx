import type { CSSProperties } from 'react'
import { motion } from 'framer-motion'
import { ArrowUpRight, Bookmark, MapPin } from 'lucide-react'
import type { Job } from '../types'

function postedLabel(days: number) {
  if (days === 1) return 'Posted yesterday'
  if (days < 7) return `Posted ${days} days ago`
  if (days < 14) return 'Posted last week'
  return `Posted ${Math.floor(days / 7)} weeks ago`
}

interface JobCardProps {
  job: Job
  index: number
  isSaved: boolean
  onSave: (jobId: string) => void
  onView: (job: Job) => void
  onApply: (job: Job) => void
}

export function JobCard({ job, index, isSaved, onSave, onView, onApply }: JobCardProps) {
  return (
    <motion.article
      className="job-card"
      initial={{ opacity: 0, y: 15 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, amount: 0.08 }}
      transition={{ duration: 0.36, delay: Math.min(index * 0.035, 0.24), ease: [0.22, 1, 0.36, 1] }}
      whileHover={{ y: -3 }}
    >
      <div className="job-card__top">
        <div className="company-mark" style={{ '--brand-color': job.brandColor } as CSSProperties} aria-hidden="true">{job.companyAbbr}</div>
        <div className="job-card__posted">{postedLabel(job.postedDays)}</div>
        <button className={`bookmark-button${isSaved ? ' is-saved' : ''}`} type="button" onClick={() => onSave(job.id)} aria-label={isSaved ? `Remove ${job.title} at ${job.company} from saved jobs` : `Save ${job.title} at ${job.company}`} aria-pressed={isSaved}>
          <Bookmark size={18} fill={isSaved ? 'currentColor' : 'none'} strokeWidth={1.8} aria-hidden="true" />
        </button>
      </div>
      <div className="job-card__company">{job.company}<span className="verified-dot" aria-label="Sample listing" title="Sample listing">✓</span></div>
      <button className="job-card__title-button" type="button" onClick={() => onView(job)}><h3>{job.title}</h3><ArrowUpRight size={16} aria-hidden="true" /></button>
      <div className="job-card__meta"><span><MapPin size={14} aria-hidden="true" />{job.location}</span><span className="meta-separator" aria-hidden="true">·</span><strong>{job.salary}</strong></div>
      <p className="job-card__description">{job.description}</p>
      <div className="job-card__tags">
        <span className="job-tag job-tag--type">{job.employmentType}</span>
        <span className="job-tag">{job.experience}</span>
        <span className="job-tag">{job.workMode}</span>
      </div>
      <div className="job-card__footer">
        <span className="job-category-label">{job.category}</span>
        <div className="job-card__actions">
          <button className="text-button" type="button" onClick={() => onView(job)}>Details <ArrowUpRight size={14} aria-hidden="true" /></button>
          <button className="button button--apply" type="button" onClick={() => onApply(job)}>Apply now</button>
        </div>
      </div>
    </motion.article>
  )
}

export function Logo({ footer = false }: { footer?: boolean }) {
  return (
    <a className={`brand${footer ? ' brand--footer' : ''}`} href="#home" aria-label="Jobora home">
      <span className="brand-mark" aria-hidden="true">
        <span className="brand-mark__tile brand-mark__tile--one" />
        <span className="brand-mark__tile brand-mark__tile--two" />
        <span className="brand-mark__tile brand-mark__tile--three" />
      </span>
      <span className="brand-word">JOBORA</span>
    </a>
  )
}

import { ArrowDownRight, ArrowRight, MapPin, Search, Sparkles } from 'lucide-react'
import { motion } from 'framer-motion'

const popularSearches = ['Developer', 'Designer', 'Marketing', 'Data Analyst', 'Internships']

interface HeroProps {
  query: string
  locationQuery: string
  onQueryChange: (value: string) => void
  onLocationChange: (value: string) => void
  onSearch: () => void
  onTag: (value: string) => void
}

export function Hero({ query, locationQuery, onQueryChange, onLocationChange, onSearch, onTag }: HeroProps) {
  return (
    <section className="hero-section" id="home">
      <div className="hero-grid-lines" aria-hidden="true" />
      <div className="container hero-layout">
        <motion.div className="hero-copy" initial={{ opacity: 0, y: 18 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.58, ease: [0.22, 1, 0.36, 1] }}>
          <div className="eyebrow hero-eyebrow"><span className="eyebrow-spark"><Sparkles size={13} /></span> A more considered way to work</div>
          <h1>Find the work that <span>moves you forward.</span></h1>
          <p className="hero-description">Explore opportunities from companies that value your skills, ambition, and potential.</p>
          <form className="hero-search" role="search" onSubmit={(event) => { event.preventDefault(); onSearch() }}>
            <label className="sr-only" htmlFor="job-search">Job title, company, or keyword</label>
            <div className="search-field search-field--role"><Search size={19} aria-hidden="true" /><input id="job-search" type="search" value={query} onChange={(event) => onQueryChange(event.target.value)} placeholder="Job title, company, or keyword" /></div>
            <span className="search-divider" aria-hidden="true" />
            <label className="sr-only" htmlFor="job-location">Location</label>
            <div className="search-field search-field--location"><MapPin size={18} aria-hidden="true" /><input id="job-location" value={locationQuery} onChange={(event) => onLocationChange(event.target.value)} placeholder="City, country, or remote" /></div>
            <button className="button button--primary search-submit" type="submit">Search jobs <ArrowRight size={16} aria-hidden="true" /></button>
          </form>
          <div className="popular-searches"><span className="popular-label">Popular:</span>{popularSearches.map((tag) => <button type="button" key={tag} onClick={() => onTag(tag)}>{tag}</button>)}</div>
          <div className="hero-proof"><div className="proof-avatars" aria-hidden="true"><span>J</span><span>M</span><span>A</span><span>+</span></div><p><strong>Curated for clarity.</strong> Every listing is sample data for this demo.</p></div>
        </motion.div>
        <motion.div className="hero-art" aria-label="An abstract illustration about finding the right work" role="img" initial={{ opacity: 0, scale: 0.96, x: 12 }} animate={{ opacity: 1, scale: 1, x: 0 }} transition={{ duration: 0.72, delay: 0.1, ease: [0.22, 1, 0.36, 1] }}>
          <svg className="hero-orbit" viewBox="0 0 520 430" fill="none" aria-hidden="true">
            <circle cx="286" cy="211" r="162" stroke="#DAD7FA" strokeWidth="1.3" />
            <circle cx="286" cy="211" r="127" stroke="#E6E4F8" strokeWidth="1" strokeDasharray="3 7" />
            <path d="M121 249c22-78 89-132 165-132 79 0 149 55 169 134" stroke="#C6C0FA" strokeWidth="1.5" strokeLinecap="round" />
            <path d="M149 283c39 51 99 82 165 82 51 0 98-19 133-51" stroke="#E3E1F6" strokeWidth="1.2" strokeLinecap="round" />
            <circle cx="134" cy="257" r="5" fill="#6257E8" />
            <circle cx="454" cy="251" r="5" fill="#6257E8" />
            <circle cx="364" cy="93" r="4" fill="#A9A1F4" />
            <path d="M133 257h73c19 0 34 15 34 34v10c0 22 18 40 40 40h111" stroke="#6257E8" strokeWidth="2" strokeLinecap="round" strokeDasharray="1 7" />
            <path d="M284 177v68m0-68 19 16m-19-16-19 16" stroke="#6257E8" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
            <circle cx="286" cy="211" r="52" fill="#EFEDFF" />
            <circle cx="286" cy="211" r="32" fill="white" />
            <path d="M278 219l8-18 8 18m-13-5h10" stroke="#6257E8" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
          <div className="hero-art__small-label">YOUR NEXT CHAPTER <span>01 / 03</span></div>
          <div className="art-card art-card--match">
            <div className="art-card__topline"><span className="art-card__pulse" /> A thoughtful match</div>
            <div className="match-role"><span className="match-role__brand">R</span><span><strong>Product Designer</strong><small>Razorpay · Bengaluru</small></span><span className="match-arrow"><ArrowRight size={15} /></span></div>
            <div className="match-score"><span>Built around your strengths</span><strong>92%</strong></div>
            <div className="match-meter"><span /></div>
          </div>
          <div className="art-card art-card--note"><span className="note-icon"><ArrowDownRight size={16} /></span><span><strong>A better fit</strong><small>Starts with a better search.</small></span></div>
          <div className="hero-art__caption"><span>JOBORA FIELD NOTE</span><span>GOOD WORK, WELL FOUND.</span></div>
        </motion.div>
      </div>
      <div className="hero-bottom container">
        <span className="hero-bottom__label">A clearer path to your next role</span>
        <div className="hero-stats"><div><strong>17</strong><span>sample openings</span></div><i /><div><strong>08</strong><span>career paths</span></div><i /><div><strong>01</strong><span>thoughtful search</span></div></div>
        <a className="hero-explore" href="#find-jobs">Explore openings <ArrowDownRight size={15} aria-hidden="true" /></a>
      </div>
    </section>
  )
}

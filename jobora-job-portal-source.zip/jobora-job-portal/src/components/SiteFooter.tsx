import { ArrowUpRight, Instagram, Linkedin, Mail } from 'lucide-react'
import { Logo } from './Logo'
import type { SiteAction } from './Navigation'
import type { InfoContent } from './InfoModal'

interface SiteFooterProps {
  onAction: (action: SiteAction) => void
  onInfo: (content: InfoContent) => void
}

export function SiteFooter({ onAction, onInfo }: SiteFooterProps) {
  return (
    <footer className="site-footer">
      <div className="container">
        <div className="footer-main">
          <div className="footer-brand-column">
            <Logo footer />
            <p>A more considered way to find work that fits your life, your values, and where you want to go next.</p>
            <a className="footer-contact" href="mailto:hello@jobora.example"><Mail size={15} /> hello@jobora.example <span>demo contact</span></a>
            <div className="footer-socials">
              <a href="https://www.linkedin.com" target="_blank" rel="noreferrer" aria-label="LinkedIn"><Linkedin size={16} /></a>
              <a href="https://www.instagram.com" target="_blank" rel="noreferrer" aria-label="Instagram"><Instagram size={16} /></a>
              <a href="https://x.com" target="_blank" rel="noreferrer" aria-label="X"><span className="social-x">𝕏</span></a>
            </div>
          </div>
          <div className="footer-link-group"><h3>Explore</h3><a href="#find-jobs">Find jobs <ArrowUpRight size={12} /></a><a href="#categories">Browse categories</a><a href="#companies">Featured companies</a><button type="button" onClick={() => onAction('post')}>For employers</button></div>
          <div className="footer-link-group"><h3>Career resources</h3><a href="#career-advice">The Jobora Journal</a><button type="button" onClick={() => onInfo({ title: 'Career resources', body: 'The Jobora Journal offers practical, static career guidance for this demo. Explore the articles above for resume, interview, and early-career tips.' })}>Interview guides</button><button type="button" onClick={() => onInfo({ title: 'Career resources', body: 'Our resource library is a visual preview. The articles on this page are sample editorial content and do not represent professional, legal, or financial advice.' })}>Job search toolkit</button></div>
          <div className="footer-link-group"><h3>About Jobora</h3><button type="button" onClick={() => onInfo({ title: 'About Jobora', body: 'Jobora is a concept for a clearer, more considered job-search experience. This frontend demo uses sample data only and is not connected to employers or applicants.' })}>Our story</button><button type="button" onClick={() => onInfo({ title: 'Privacy, in plain language', body: 'This demo has no backend, analytics, or application storage. Form entries and selected files stay in your current browser session and are not transmitted.' })}>Privacy policy</button><button type="button" onClick={() => onInfo({ title: 'Terms of use', body: 'Job listings, company names, salaries, and editorial content are illustrative demonstration data. They are not verified vacancies, offers, or professional advice.' })}>Terms & conditions</button></div>
        </div>
        <div className="footer-bottom"><span>© 2026 Jobora. A thoughtful search, in progress.</span><span className="footer-demo-note"><i /> Frontend demo · sample listings only</span><a href="#home">Back to top <ArrowUpRight size={13} /></a></div>
      </div>
    </footer>
  )
}

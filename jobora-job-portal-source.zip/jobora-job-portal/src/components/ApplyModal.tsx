import { useEffect, useState, type ChangeEvent, type FormEvent } from 'react'
import { ArrowLeft, Check, FileText, Upload } from 'lucide-react'
import type { Job } from '../types'
import { Dialog } from './Dialog'

type FormValues = { fullName: string; email: string; phone: string; linkedin: string; cover: string }
type FieldErrors = Partial<Record<keyof FormValues | 'resume', string>>

const emptyValues: FormValues = { fullName: '', email: '', phone: '', linkedin: '', cover: '' }

interface ApplyModalProps {
  job: Job | null
  onClose: () => void
}

export function ApplyModal({ job, onClose }: ApplyModalProps) {
  const [values, setValues] = useState<FormValues>(emptyValues)
  const [resume, setResume] = useState<File | null>(null)
  const [errors, setErrors] = useState<FieldErrors>({})
  const [submitted, setSubmitted] = useState(false)

  useEffect(() => {
    if (!job) return
    setValues(emptyValues)
    setResume(null)
    setErrors({})
    setSubmitted(false)
  }, [job?.id])

  const updateField = (key: keyof FormValues, value: string) => {
    setValues((current) => ({ ...current, [key]: value }))
    setErrors((current) => ({ ...current, [key]: undefined }))
  }

  const handleResume = (event: ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0] ?? null
    setResume(file)
    setErrors((current) => ({ ...current, resume: undefined }))
  }

  const submit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault()
    const nextErrors: FieldErrors = {}
    if (values.fullName.trim().length < 2) nextErrors.fullName = 'Please enter your full name.'
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(values.email.trim())) nextErrors.email = 'Enter a valid email address.'
    const digits = values.phone.replace(/\D/g, '')
    if (digits.length < 10 || digits.length > 15) nextErrors.phone = 'Use a phone number with 10–15 digits.'
    if (values.linkedin.trim()) {
      try {
        const url = new URL(values.linkedin.startsWith('http') ? values.linkedin : `https://${values.linkedin}`)
        if (!/(^|\.)linkedin\.com$/i.test(url.hostname)) nextErrors.linkedin = 'Enter a valid LinkedIn profile URL.'
      } catch {
        nextErrors.linkedin = 'Enter a valid LinkedIn profile URL.'
      }
    }
    if (!resume) nextErrors.resume = 'Please attach a resume to continue.'
    else {
      const supported = /\.(pdf|doc|docx)$/i.test(resume.name)
      if (!supported) nextErrors.resume = 'Upload a PDF, DOC, or DOCX file.'
      else if (resume.size > 10 * 1024 * 1024) nextErrors.resume = 'The file must be smaller than 10 MB.'
    }
    setErrors(nextErrors)
    if (Object.keys(nextErrors).length === 0) setSubmitted(true)
  }

  return (
    <Dialog open={Boolean(job)} onClose={onClose} labelledBy="apply-dialog-title" className="dialog--apply">
      {job && (submitted ? (
        <div className="application-success">
          <span className="success-icon"><Check size={24} strokeWidth={2.2} /></span>
          <span className="eyebrow">Application preview</span>
          <h2 id="apply-dialog-title">You’re ready for your next step.</h2>
          <p>Your demo application for <strong>{job.title}</strong> at <strong>{job.company}</strong> passed local validation.</p>
          <div className="privacy-callout"><strong>Nothing was sent or stored.</strong><br />This is a frontend-only demonstration. Your details and resume stay in this page session.</div>
          <button className="button button--primary button--full" type="button" onClick={onClose}>Done</button>
        </div>
      ) : (
        <div className="apply-content">
          <button className="back-link" type="button" onClick={onClose}><ArrowLeft size={15} /> Back to role</button>
          <div className="apply-heading">
            <span className="eyebrow">Application preview</span>
            <h2 id="apply-dialog-title">Make your next move.</h2>
            <p>Applying for <strong>{job.title}</strong> at {job.company}</p>
          </div>
          <form className="application-form" onSubmit={submit} noValidate>
            <div className="form-grid">
              <div className="form-field">
                <label htmlFor="apply-name">Full name <span>*</span></label>
                <input id="apply-name" autoComplete="name" value={values.fullName} onChange={(event) => updateField('fullName', event.target.value)} placeholder="e.g. Aanya Mehta" aria-invalid={Boolean(errors.fullName)} aria-describedby={errors.fullName ? 'error-name' : undefined} />
                {errors.fullName && <span id="error-name" className="field-error">{errors.fullName}</span>}
              </div>
              <div className="form-field">
                <label htmlFor="apply-email">Email address <span>*</span></label>
                <input id="apply-email" type="email" autoComplete="email" value={values.email} onChange={(event) => updateField('email', event.target.value)} placeholder="you@example.com" aria-invalid={Boolean(errors.email)} aria-describedby={errors.email ? 'error-email' : undefined} />
                {errors.email && <span id="error-email" className="field-error">{errors.email}</span>}
              </div>
              <div className="form-field">
                <label htmlFor="apply-phone">Phone number <span>*</span></label>
                <input id="apply-phone" type="tel" inputMode="tel" autoComplete="tel" value={values.phone} onChange={(event) => updateField('phone', event.target.value)} placeholder="+91 98765 43210" aria-invalid={Boolean(errors.phone)} aria-describedby={errors.phone ? 'error-phone' : undefined} />
                {errors.phone && <span id="error-phone" className="field-error">{errors.phone}</span>}
              </div>
              <div className="form-field">
                <label htmlFor="apply-linkedin">LinkedIn profile <span className="optional-label">Optional</span></label>
                <input id="apply-linkedin" type="url" autoComplete="url" value={values.linkedin} onChange={(event) => updateField('linkedin', event.target.value)} placeholder="linkedin.com/in/yourname" aria-invalid={Boolean(errors.linkedin)} aria-describedby={errors.linkedin ? 'error-linkedin' : undefined} />
                {errors.linkedin && <span id="error-linkedin" className="field-error">{errors.linkedin}</span>}
              </div>
            </div>
            <div className="form-field">
              <label htmlFor="resume-upload">Resume <span>*</span><span className="optional-label">PDF, DOC, or DOCX · max 10 MB</span></label>
              <label className={`upload-field${resume ? ' upload-field--has-file' : ''}`} htmlFor="resume-upload">
                <input id="resume-upload" type="file" accept=".pdf,.doc,.docx,application/pdf,application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document" onChange={handleResume} aria-describedby={errors.resume ? 'error-resume' : 'resume-help'} />
                <span className="upload-field__icon">{resume ? <FileText size={19} /> : <Upload size={19} />}</span>
                <span className="upload-field__copy"><strong>{resume ? resume.name : 'Choose a file to attach'}</strong><small id="resume-help">{resume ? `${(resume.size / (1024 * 1024)).toFixed(2)} MB · ready for demo validation` : 'Your file stays in this browser session.'}</small></span>
                <span className="upload-field__browse">Browse</span>
              </label>
              {errors.resume && <span id="error-resume" className="field-error">{errors.resume}</span>}
            </div>
            <div className="form-field">
              <label htmlFor="apply-cover">A note for the team <span className="optional-label">Optional · up to 500 characters</span></label>
              <textarea id="apply-cover" rows={3} maxLength={500} value={values.cover} onChange={(event) => updateField('cover', event.target.value)} placeholder="What makes this opportunity interesting to you?" />
              <span className="character-count">{values.cover.length}/500</span>
            </div>
            <p className="form-privacy">Demo only. Submitting validates this form locally; nothing is transmitted, saved, or shared.</p>
            <button className="button button--primary button--full" type="submit">Submit application preview <ArrowLeft className="button-arrow" size={16} /></button>
          </form>
        </div>
      ))}
    </Dialog>
  )
}

import { ArrowRight, Sparkles } from 'lucide-react'
import { Dialog } from './Dialog'

export interface InfoContent {
  title: string
  body: string
  cta?: string
}

export function InfoModal({ content, onClose }: { content: InfoContent | null; onClose: () => void }) {
  return (
    <Dialog open={Boolean(content)} onClose={onClose} labelledBy="info-dialog-title" className="dialog--info">
      {content && (
        <div className="info-modal-content">
          <span className="info-modal-icon"><Sparkles size={22} /></span>
          <span className="eyebrow">A Jobora preview</span>
          <h2 id="info-dialog-title">{content.title}</h2>
          <p>{content.body}</p>
          <div className="privacy-callout">This product experience is a frontend demonstration. No account, job post, or personal information is created or sent.</div>
          <button className="button button--primary button--full" type="button" onClick={onClose}>{content.cta ?? 'Got it'} <ArrowRight size={16} /></button>
        </div>
      )}
    </Dialog>
  )
}

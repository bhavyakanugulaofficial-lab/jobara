import { ArrowUpRight, BarChart3, BriefcaseBusiness, Code2, Cog, Headphones, Megaphone, PenTool, UsersRound } from 'lucide-react'
import { motion } from 'framer-motion'
import { jobCategories, type JobCategory } from '../types'

const icons = [Code2, PenTool, Megaphone, BriefcaseBusiness, BarChart3, UsersRound, Headphones, Cog]

interface CategoryGridProps {
  counts: Record<JobCategory, number>
  onSelect: (category: JobCategory) => void
}

export function CategoryGrid({ counts, onSelect }: CategoryGridProps) {
  return (
    <div className="category-grid">
      {jobCategories.map((category, index) => {
        const Icon = icons[index]
        return (
          <motion.button
            className="category-card"
            type="button"
            key={category}
            onClick={() => onSelect(category)}
            initial={{ opacity: 0, y: 12 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.12 }}
            transition={{ duration: 0.32, delay: index * 0.04 }}
            whileHover={{ y: -4 }}
          >
            <span className="category-card__icon"><Icon size={19} strokeWidth={1.75} aria-hidden="true" /></span>
            <span className="category-card__name">{category}</span>
            <span className="category-card__bottom"><span>{counts[category]} sample {counts[category] === 1 ? 'role' : 'roles'}</span><ArrowUpRight size={15} aria-hidden="true" /></span>
          </motion.button>
        )
      })}
    </div>
  )
}

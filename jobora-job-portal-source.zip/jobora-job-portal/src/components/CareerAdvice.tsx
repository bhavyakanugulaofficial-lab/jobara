import { ArrowUpRight, BookOpen, Clock3 } from 'lucide-react'
import { motion } from 'framer-motion'
import type { Article } from '../types'

export function CareerAdvice({ articles, onRead }: { articles: Article[]; onRead: (article: Article) => void }) {
  return (
    <section className="advice-section section" id="career-advice">
      <div className="container">
        <div className="section-heading section-heading--row">
          <div><span className="eyebrow">THE JOBORA JOURNAL</span><h2>Good advice. <span>Good momentum.</span></h2></div>
          <p>Practical notes for the moments that shape a career — from the first application to what comes after.</p>
        </div>
        <div className="advice-grid">
          {articles.map((article, index) => (
            <motion.article className="advice-card" key={article.id} initial={{ opacity: 0, y: 14 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true, amount: 0.14 }} transition={{ duration: 0.36, delay: index * 0.07 }}>
              <button className={`article-art article-art--${article.art}`} type="button" onClick={() => onRead(article)} aria-label={`Read ${article.title}`}>
                <span className="article-art__overline">JOBORA FIELD NOTES <span>{String(index + 1).padStart(2, '0')}</span></span>
                <span className="article-art__large">{article.art === 'resume' ? <>MAKE IT<br />CLEAR.</> : article.art === 'interview' ? <>THINK OUT<br />LOUD.</> : <>START WITH<br />CURIOSITY.</>}</span>
                <span className="article-art__stamp"><BookOpen size={17} /></span>
                <span className={`article-art__motif article-art__motif--${article.art}`} aria-hidden="true"><i /><i /><i /></span>
              </button>
              <div className="advice-card__content">
                <div className="article-meta"><span>{article.category}</span><span className="article-dot">·</span><span><Clock3 size={13} />{article.readTime}</span></div>
                <h3>{article.title}</h3>
                <p>{article.excerpt}</p>
                <button className="article-read" type="button" onClick={() => onRead(article)}>Read article <ArrowUpRight size={15} /></button>
              </div>
            </motion.article>
          ))}
        </div>
      </div>
    </section>
  )
}

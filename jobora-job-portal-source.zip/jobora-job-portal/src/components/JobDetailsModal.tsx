import type { CSSProperties } from 'react'
import { ArrowUpRight, BriefcaseBusiness, Building2, MapPin } from 'lucide-react'
import { Dialog } from './Dialog'
import type { Job } from '../types'

interface JobDetailsModalProps {
  job: Job | null
  onClose: () => void
  onApply: (job: Job) => void
}

export function JobDetailsModal({ job, onClose, onApply }: JobDetailsModalProps) {
  return (
    <Dialog open={Boolean(job)} onClose={onClose} labelledBy="job-dialog-title" className="dialog--job">
      {job && (
        <div className="job-detail-content">
          <div className="job-detail-head">
            <div className="company-mark company-mark--large" style={{ '--brand-color': job.brandColor } as CSSProperties} aria-hidden="true">{job.companyAbbr}</div>
            <div className="job-detail-head__copy">
              <div className="job-card__company">{job.company}<span className="verified-dot" title="Demonstration listing">✓</span></div>
              <h2 id="job-dialog-title">{job.title}</h2>
              <div className="job-detail-head__meta"><span><MapPin size={14} />{job.location}</span><span><BriefcaseBusiness size={14} />{job.employmentType} · {job.workMode}</span></div>
            </div>
            <div className="job-detail-head__salary"><span>Compensation</span><strong>{job.salary}</strong><small>{job.experience}</small></div>
          </div>
          <div className="detail-demo-note"><span className="filter-note__dot" /> Demonstration listing — not a verified live vacancy</div>
          <div className="job-detail-columns">
            <div className="job-detail-main">
              <section className="detail-section"><h3>About the role</h3><p>{job.about}</p></section>
              <section className="detail-section"><h3>What you’ll do</h3><ul>{job.responsibilities.map((item) => <li key={item}>{item}</li>)}</ul></section>
              <section className="detail-section"><h3>What you’ll bring</h3><ul>{job.qualifications.map((item) => <li key={item}>{item}</li>)}</ul></section>
              <section className="detail-section"><h3>Skills & experience</h3><div className="skill-list">{job.skills.map((skill) => <span className="job-tag" key={skill}>{skill}</span>)}</div></section>
            </div>
            <aside className="company-detail-card">
              <div className="detail-section__eyebrow"><Building2 size={15} /> Company</div>
              <div className="company-detail-card__name">{job.company}</div>
              <p>{job.companyDescription}</p>
              <div className="company-detail-card__line"><MapPin size={14} /> {job.location}</div>
              <div className="company-detail-card__line"><BriefcaseBusiness size={14} /> {job.category}</div>
            </aside>
          </div>
          <div className="job-detail-footer">
            <span>Applications in this demo are not sent to {job.company}.</span>
            <button className="button button--primary" type="button" onClick={() => onApply(job)}>Apply now <ArrowUpRight size={16} /></button>
          </div>
        </div>
      )}
    </Dialog>
  )
}

import { useEffect, useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import { ArrowUpRight, CircleUserRound, Menu, X } from 'lucide-react'
import { Logo } from './Logo'

export type SiteAction = 'login' | 'post' | 'profile'

const links = [
  { label: 'Home', href: '#home' },
  { label: 'Find jobs', href: '#find-jobs' },
  { label: 'Companies', href: '#companies' },
  { label: 'Career advice', href: '#career-advice' },
]

export function Navigation({ onAction }: { onAction: (action: SiteAction) => void }) {
  const [menuOpen, setMenuOpen] = useState(false)
  const [scrolled, setScrolled] = useState(false)

  useEffect(() => {
    const update = () => setScrolled(window.scrollY > 12)
    update()
    window.addEventListener('scroll', update, { passive: true })
    return () => window.removeEventListener('scroll', update)
  }, [])

  const closeMenu = () => setMenuOpen(false)

  return (
    <header className={`site-header${scrolled ? ' site-header--scrolled' : ''}`}>
      <div className="nav-inner">
        <Logo />
        <nav className="desktop-nav" aria-label="Main navigation">
          {links.map((link) => (
            <a href={link.href} key={link.href}>{link.label}</a>
          ))}
        </nav>
        <div className="nav-actions">
          <button className="nav-login" type="button" onClick={() => onAction('login')}>Log in</button>
          <button className="button button--small button--dark nav-post" type="button" onClick={() => onAction('post')}>
            Post a job <ArrowUpRight size={14} aria-hidden="true" />
          </button>
          <button className="profile-button" type="button" aria-label="Open profile preview" onClick={() => onAction('profile')}>
            <CircleUserRound size={21} strokeWidth={1.65} aria-hidden="true" />
          </button>
          <button className="mobile-menu-toggle icon-button" type="button" aria-label={menuOpen ? 'Close menu' : 'Open menu'} aria-expanded={menuOpen} onClick={() => setMenuOpen((value) => !value)}>
            {menuOpen ? <X size={20} /> : <Menu size={20} />}
          </button>
        </div>
      </div>
      <AnimatePresence>
        {menuOpen && (
          <motion.div
            className="mobile-menu"
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.24, ease: 'easeOut' }}
          >
            <nav aria-label="Mobile navigation">
              {links.map((link) => (
                <a href={link.href} key={link.href} onClick={closeMenu}>{link.label}</a>
              ))}
              <button type="button" onClick={() => { closeMenu(); onAction('login') }}>Log in</button>
              <button type="button" onClick={() => { closeMenu(); onAction('post') }}>Post a job <ArrowUpRight size={14} /></button>
            </nav>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  )
}

import type { CSSProperties } from 'react'
import { ArrowUpRight, MapPin } from 'lucide-react'
import { motion } from 'framer-motion'
import type { Job } from '../types'
import { featuredCompanies } from '../data/content'

export function CompaniesSection({ jobs, onCompanyClick }: { jobs: Job[]; onCompanyClick: (company: string) => void }) {
  return (
    <section className="companies-section section" id="companies">
      <div className="container">
        <div className="section-heading section-heading--row">
          <div><span className="eyebrow">GOOD COMPANY</span><h2>Meet the teams<br className="desktop-break" /> behind the work.</h2></div>
          <p>Explore a few of the organisations represented in our sample listings. Great work starts with people who care about how it gets done.</p>
        </div>
        <div className="company-grid">
          {featuredCompanies.map((company, index) => {
            const count = jobs.filter((job) => job.company === company.name).length
            return (
              <motion.article className="company-card" key={company.name} initial={{ opacity: 0, y: 12 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true, amount: 0.12 }} transition={{ duration: 0.34, delay: index * 0.05 }}>
                <div className="company-card__top"><span className="company-mark" style={{ '--brand-color': company.color } as CSSProperties} aria-hidden="true">{company.abbr}</span><span className="company-openings">{count} sample {count === 1 ? 'opening' : 'openings'}</span></div>
                <h3>{company.name}</h3>
                <p className="company-card__industry">{company.industry}</p>
                <p className="company-card__note">{company.note}</p>
                <div className="company-card__bottom"><span><MapPin size={13} />{company.location}</span><button type="button" onClick={() => onCompanyClick(company.name)} aria-label={`Explore sample openings at ${company.name}`}><ArrowUpRight size={16} /></button></div>
              </motion.article>
            )
          })}
        </div>
        <p className="company-disclaimer">Company names and openings are presented for demonstration purposes only.</p>
      </div>
    </section>
  )
}

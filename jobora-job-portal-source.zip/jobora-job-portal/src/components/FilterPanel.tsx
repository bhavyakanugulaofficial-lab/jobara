import { SlidersHorizontal, X } from 'lucide-react'
import { jobCategories, type JobFilters } from '../types'

interface FilterPanelProps {
  filters: JobFilters
  onChange: (key: keyof JobFilters, value: string) => void
  onClear: () => void
  locations: string[]
  isOpen: boolean
  onClose: () => void
}

export function FilterPanel({ filters, onChange, onClear, locations, isOpen, onClose }: FilterPanelProps) {
  const activeCount = [filters.category, filters.location, filters.type, filters.experience, filters.salary].filter(Boolean).length

  return (
    <aside className={`filter-panel${isOpen ? ' filter-panel--open' : ''}`} aria-label="Job filters">
      <div className="filter-panel__heading">
        <div className="filter-title"><SlidersHorizontal size={17} aria-hidden="true" /><h3>Refine results</h3></div>
        <button className="filter-mobile-close icon-button" type="button" aria-label="Close filters" onClick={onClose}><X size={18} /></button>
        <button className="filter-clear" type="button" onClick={onClear} disabled={activeCount === 0 && !filters.locationQuery && !filters.query}>Clear all</button>
      </div>
      <div className="filter-group">
        <label htmlFor="filter-location">Location</label>
        <select id="filter-location" value={filters.location} onChange={(event) => onChange('location', event.target.value)}>
          <option value="">Anywhere</option>
          {locations.map((location) => <option key={location} value={location}>{location}</option>)}
        </select>
      </div>
      <div className="filter-group">
        <label htmlFor="filter-category">Category</label>
        <select id="filter-category" value={filters.category} onChange={(event) => onChange('category', event.target.value)}>
          <option value="">All categories</option>
          {jobCategories.map((category) => <option key={category} value={category}>{category}</option>)}
        </select>
      </div>
      <div className="filter-group">
        <label htmlFor="filter-type">Employment type</label>
        <select id="filter-type" value={filters.type} onChange={(event) => onChange('type', event.target.value)}>
          <option value="">Any type</option>
          <option value="Full-time">Full-time</option>
          <option value="Part-time">Part-time</option>
          <option value="Internship">Internship</option>
          <option value="Remote">Remote</option>
        </select>
      </div>
      <div className="filter-group">
        <label htmlFor="filter-experience">Experience level</label>
        <select id="filter-experience" value={filters.experience} onChange={(event) => onChange('experience', event.target.value)}>
          <option value="">Any experience</option>
          <option value="Entry level">Entry level</option>
          <option value="Mid-level">Mid-level</option>
          <option value="Senior">Senior</option>
        </select>
      </div>
      <div className="filter-group">
        <label htmlFor="filter-salary">Salary range</label>
        <select id="filter-salary" value={filters.salary} onChange={(event) => onChange('salary', event.target.value)}>
          <option value="">Any salary</option>
          <option value="under10">Under ₹10 LPA</option>
          <option value="10to20">₹10–20 LPA</option>
          <option value="20to35">₹20–35 LPA</option>
          <option value="35plus">₹35 LPA and above</option>
        </select>
        <span className="filter-hint">International salaries are normalised for filtering; the card shows the original range.</span>
      </div>
      <div className="filter-note"><span className="filter-note__dot" /> Showing illustrative sample listings</div>
    </aside>
  )
}

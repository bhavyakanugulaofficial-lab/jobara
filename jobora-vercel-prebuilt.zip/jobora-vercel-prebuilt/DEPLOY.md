# Deploy Jobora to the linked Vercel project

This archive contains a Vercel Build Output API v3 static site package, already linked to the existing `jobora-job-portal` Vercel project. It requires Node.js/npm and the Vercel CLI, but no rebuild.

1. Extract this ZIP into a folder (keep the hidden `.vercel` directory).
2. Open a terminal in the extracted folder.
3. Run `npx --yes vercel@latest deploy --prebuilt --prod`.
4. If prompted, sign into the Vercel account that owns the `jobora-job-portal` project.

This deploys the static build. The source project is available separately in `jobora-job-portal-source.zip`. The sample jobs remain illustrative; application data is not transmitted or stored.
